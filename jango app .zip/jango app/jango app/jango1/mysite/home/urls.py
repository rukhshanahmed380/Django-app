#This file is created by us
from django.contrib import admin
from django.urls import path, include
# this line is also included by us
from home import views

admin.site.site_header = "Login to Developer Safiullah"
admin.site.site_title = "Welcome to BSSE Dashboard"
admin.site.index_title = "Welcome to this portal"

# After creating project url file, make urls.py file in app
# and then configure your pages in this file

urlpatterns = [
    path('', views.home, name='home'),
    path('about', views.about, name='about'),
    path('contact', views.contact, name='contact'),
    path('projects', views.projects, name='projects'),
    
]